#include "sum_driver.hpp"
#include <stdio.h> 
#include <stdlib.h>
#include <time.h>

sum_driver::
sum_driver
(void)
{
  char * default_error_name = "sum.err";
 
  {
 
  }


}

sum_driver::
~sum_driver
(void)
{
 
    
}

void
sum_driver::
go
()
{
    int guessingNum = rand() % 100; //number from 1 - 100
    int noOfTimes = 0;
    int numberGuesser = 0;

    printf("Guess a number from 1 - 100 to find out what the number is.");

    while (guessingNum != numberGuesser) {
        scanf("%d", &numberGuesser);

        if (numberGuesser > guessingNum) { //if greater
            printf("%d is greater than the actual number. Guess again!", numberGuesser);
            noOfTimes++;
        }
        if (numberGuesser < guessingNum) { //if less
            printf("%d is less than the actual number. Guess again!", numberGuesser);
            noOfTimes++;
        }
    }

    printf("Congratulations! You guessed it correctly! It took you %d tries! Press escape to leave.", noOfTimes);

}


  



