#ifndef sum_driver_HPP
#define sum_driver_HPP


using namespace std;

class sum_driver
{
  // Class methods
public:

  // Constructor
  sum_driver(void);

  // Destructor
  ~sum_driver(void);

  void go();
  


  // Attributes
protected:


	int numberGuesser;
};

#endif sum_driver_HPP
