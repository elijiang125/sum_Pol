
import cmake-converter

print("hello")